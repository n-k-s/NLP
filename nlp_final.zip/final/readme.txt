https://www.youtube.com/watch?v=wNqcfMwK0U4&feature=youtu.be
can be run just by typing python final_project.py or by running it in pycharm
NLTK
	needed instals
		punkt
		averaged_perception_tagger
	wordnet, word_tokenize, pos_tag
